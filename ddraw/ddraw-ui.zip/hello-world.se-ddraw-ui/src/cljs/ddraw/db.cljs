(ns ddraw.db)

(def default-db
  {:authenticated? false
   :listening? false
   :queue-created? false
   :current-shape nil
   :shapes []})
